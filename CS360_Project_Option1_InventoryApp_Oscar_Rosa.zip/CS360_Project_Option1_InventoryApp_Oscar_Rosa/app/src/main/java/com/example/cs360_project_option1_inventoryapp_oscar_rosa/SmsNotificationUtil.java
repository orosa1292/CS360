package com.example.cs360_project_option1_inventoryapp_oscar_rosa;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsNotificationUtil {
    private static final String TAG = "SmsNotificationUtil";
    public static final int SMS_PERMISSION_REQUEST_CODE = 1;

    public static void sendLowInventoryNotification(Context context, String itemName, int quantity) {
        if (checkSmsPermission(context)) {
            sendSms(context, itemName, quantity);
        } else {
            requestSmsPermission(context);
        }
    }

    private static boolean checkSmsPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private static void requestSmsPermission(Context context) {
        if (context instanceof Activity) {
            ActivityCompat.requestPermissions((Activity) context,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
            Toast.makeText(context, "SMS permission required to send notifications", Toast.LENGTH_LONG).show();
        } else {
            Log.e(TAG, "Context is not an instance of Activity. Cannot request permissions.");
        }
    }

    private static void sendSms(Context context, String itemName, int quantity) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String message = "Low inventory alert: " + itemName + " is low on stock. Current quantity: " + quantity;
            String phoneNumber = "YOUR_PHONE_NUMBER"; // Replace with actual phone number
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(context, "Low inventory notification sent", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "SMS sent successfully for " + itemName);
        } catch (Exception e) {
            Log.e(TAG, "Failed to send SMS", e);
            Toast.makeText(context, "Failed to send SMS notification", Toast.LENGTH_SHORT).show();
        }
    }
}